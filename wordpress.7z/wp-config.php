<?php
/**
 * Основные параметры WordPress.
 *
 * Скрипт для создания wp-config.php использует этот файл в процессе установки.
 * Необязательно использовать веб-интерфейс, можно скопировать файл в "wp-config.php"
 * и заполнить значения вручную.
 *
 * Этот файл содержит следующие параметры:
 *
 * * Настройки базы данных
 * * Секретные ключи
 * * Префикс таблиц базы данных
 * * ABSPATH
 *
 * @link https://ru.wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Параметры базы данных: Эту информацию можно получить у вашего хостинг-провайдера ** //
/** Имя базы данных для WordPress */
define( 'DB_NAME', 'mysite7.rus' );

/** Имя пользователя базы данных */
define( 'DB_USER', 'admin' );

/** Пароль к базе данных */
define( 'DB_PASSWORD', '1111b' );

/** Имя сервера базы данных */
define( 'DB_HOST', 'localhost' );

/** Кодировка базы данных для создания таблиц. */
define( 'DB_CHARSET', 'utf8mb4' );

/** Схема сопоставления. Не меняйте, если не уверены. */
define( 'DB_COLLATE', '' );

/**#@+
 * Уникальные ключи и соли для аутентификации.
 *
 * Смените значение каждой константы на уникальную фразу. Можно сгенерировать их с помощью
 * {@link https://api.wordpress.org/secret-key/1.1/salt/ сервиса ключей на WordPress.org}.
 *
 * Можно изменить их, чтобы сделать существующие файлы cookies недействительными.
 * Пользователям потребуется авторизоваться снова.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '0xV(7,xm!ET{]]|RMEX5eGxXY/j g6Tl+cfHmjQ[zCj8w=qGj}c5^fj:^3I}%Md1' );
define( 'SECURE_AUTH_KEY',  'ZgS9udxmZ}?tMflN_NB?2wo5fx#>Bf2.HnVI B9F09#,4argbYE1&q*+jqUys35*' );
define( 'LOGGED_IN_KEY',    '4G/|%c1#tAj`7LL&t2SHz3xxcKjx1-;6QD ;rif;x1e3(6Yazc2[weD#bcYq/b.r' );
define( 'NONCE_KEY',        'p; 5tgm}64T$+vyUfE::>=nZi2lZS{GRF$fE#2e2l{#[rn@F>35xdR}VA4&_%`2d' );
define( 'AUTH_SALT',        'ESM*%zM_HdW}qjpxpMU{&g55+Dsnx&--Vz3S!nMGRG?T*a U>*Y>EhJ|y C%W%d@' );
define( 'SECURE_AUTH_SALT', 'wlpgAEQaWD^%3p)V+JT+.&W}x1~5zj@?&@X9f&ojXIPH2O,=_89K!a?7=Pcfq^fw' );
define( 'LOGGED_IN_SALT',   'B{,bnVpn(D4j7:N4DBPJ@|]5A!AE%tvo]|D28N$kvlhe_UtIH+k1r|Fyj>r06yAE' );
define( 'NONCE_SALT',       '{&}hb0YI|fDT?gRd>:[F6C=oIiz3^_SS$A#:cXNKbJaGH3TdA(?jorLcFlR8CG2C' );

/**#@-*/

/**
 * Префикс таблиц в базе данных WordPress.
 *
 * Можно установить несколько сайтов в одну базу данных, если использовать
 * разные префиксы. Пожалуйста, указывайте только цифры, буквы и знак подчеркивания.
 */
$table_prefix = 'wp_';

/**
 * Для разработчиков: Режим отладки WordPress.
 *
 * Измените это значение на true, чтобы включить отображение уведомлений при разработке.
 * Разработчикам плагинов и тем настоятельно рекомендуется использовать WP_DEBUG
 * в своём рабочем окружении.
 *
 * Информацию о других отладочных константах можно найти в документации.
 *
 * @link https://ru.wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Произвольные значения добавляйте между этой строкой и надписью "дальше не редактируем". */



/* Это всё, дальше не редактируем. Успехов! */

/** Абсолютный путь к директории WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Инициализирует переменные WordPress и подключает файлы. */
require_once ABSPATH . 'wp-settings.php';
